import { Router } from 'express';
import { env } from '../config/env.js';
import authRoutes from './auth.routes.js';
import problemRoutes from './problem.routes.js';
import submissionRoutes from './submission.routes.js';
import userRoutes from './user.routes.js';
import adminRoutes from './admin/admin.routes.js';
import aiRoutes from './ai.routes.js';
import aptitudeRoutes from './aptitude.routes.js'; 
import billingRoutes from './billing.routes.js';
import licenseRoutes from './license.routes.js';
import prepRoutes from './prep.routes.js';
import roomRoutes from './room.routes.js';
import studyPlanRoutes from './studyPlan.routes.js';
import leaderboardRoutes from './leaderboard.routes.js';
import '../models/AdminActionLog.js';

const router = Router();

router.get('/health', (req, res) =>
  res.json({
    success: true,
    message: 'JeetCode API is up',
    freeAccessUntil: env.FREE_ACCESS_UNTIL || null,
  })
);

router.use('/auth', authRoutes);
router.use('/problems', problemRoutes);
router.use('/billing', billingRoutes);
router.use('/submissions', submissionRoutes);
router.use('/users', userRoutes);
router.use('/admin', adminRoutes);
router.use('/ai', aiRoutes);
router.use('/aptitude', aptitudeRoutes); 
router.use('/licenses', licenseRoutes);
router.use('/prep', prepRoutes);
router.use('/rooms', roomRoutes);
router.use('/study-plans', studyPlanRoutes);
router.use('/leaderboard', leaderboardRoutes);


export default router;
